<html>
<head>
<title>Biophp.org - minitools</title>
</head>
<body bgcolor=ffffff>
<h2>BioPHP - Minitools</h2>
The minitools bellow were downloaded on 2019-03-04
<hr>
<br><a href=chaos_game_representation/index.php></a>
<br><a href=distance_among_sequences/index.php>Oligonucleotide frequency based distance among sequences
</a>
<br><a href=dna_to_protein/index.php>DNA to protein translation
</a>
<br><a href=find_palindromes/index.php>Palindromic sequences finder
</a>
<br><a href=gc_content_finder/index.php>GC Contenf Finder</a>
<br><a href=melting_temperature/index.php>Melting Temperature (Tm) Calculation
</a>
<br><a href=microarray_analysis_adaptive_quantification/index.php>Microarray Data Analysis (adaptive quantification method)
</a>
<br><a href=microsatellite_repeats_finder/index.php>Microsatellite repeats finder
</a>
<br><a href=oligonucleotide_frequency/index.php>Frequency of nucleotides and oligonucleotides
</a>
<br><a href=pcr_amplification/index.php>PCR amplification
</a>
<br><a href=protein_properties/index.php>Protein sequence properties
</a>
<br><a href=protein_to_dna/index.php>Protein to DNA reverse translation
</a>
<br><a href=random_seqs/index.php>Random sequences</a>
<br><a href=reader_gff_fasta/index.php>Reader</a>
<br><a href=reduce_protein_alphabet/index.php>Reduced alphabets for proteins</a>
<br><a href=restriction_digest/index.php>Restriction enzyme digest of DNA
</a>
<br><a href=seq_alignment/index.php>Alignment of two DNA, RNA or protein sequences
</a>
<br><a href=sequence_manipulation_and_data/index.php>DNA sequence manipulation/properties
</a>
<br><a href=skews/index.php>GC-, AT-, KETO- and oligo-skews generator
</a>
<br><a href=useful_formulas/index.php>Formula functions</a>
<hr>
<a href=http://www.biophp.org>BioPHP.org</a>
</body>
</html>