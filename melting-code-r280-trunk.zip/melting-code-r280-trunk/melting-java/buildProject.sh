#!/bin/bash

ant compile
ant bigjar
ant javadoc
